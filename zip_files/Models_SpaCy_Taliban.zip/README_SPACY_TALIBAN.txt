========================================================================
VERITAS AI - SPACY AFGHANISTAN/TALIBAN NLP MODEL PACKAGE
========================================================================

Contents:
- modeltaliban/: Pre-trained SpaCy pipeline for Afghanistan/Taliban fake news classification
  (tokenizer, tagger, parser, ner, textcat, word vectors)

Loading in Python:
    import spacy
    nlp = spacy.load("modeltaliban")
    doc = nlp("Taliban bans polio vaccinations")
    print(doc.cats)
