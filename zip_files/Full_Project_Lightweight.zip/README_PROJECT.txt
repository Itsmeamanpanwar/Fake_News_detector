========================================================================
VERITAS AI - COMPLETE LIGHTWEIGHT PROJECT ARCHIVE (ALL-IN-ONE)
========================================================================

This complete package includes Frontend, Backend, Datasets, Sklearn Models,
Jupyter Notebooks, and Presentation slides (~4.3 MB total).
It excludes the large 140MB raw SpaCy neural weights to allow instant uploading
online to GitHub, Google Classroom, or university portals without hitting server limits.
