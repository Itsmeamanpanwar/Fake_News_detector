========================================================================
VERITAS AI - FRONTEND WEB PORTAL & UI MODULE
========================================================================

Contents:
- login.html, register.html: Web authentication UI interfaces
- style.css: Modern responsive frontend stylesheet
- connection.php, authen1.php, authen3.php: PHP database auth scripts
- bg3.PNG, side.png, bar.png, cov.png: High-resolution UI assets
- streamlit_factcheck.py: Veritas AI Interactive Dashboard UI

How to run the Web Portal (PHP/HTML):
1. Place this directory inside your XAMPP/htdocs directory (e.g. htdocs/fakenews/).
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/fakenews/login.html in your browser.
4. On successful login, it redirects to the Streamlit dashboard (http://localhost:8501).

How to run the Streamlit Web UI:
$ pip install streamlit
$ streamlit run streamlit_factcheck.py
