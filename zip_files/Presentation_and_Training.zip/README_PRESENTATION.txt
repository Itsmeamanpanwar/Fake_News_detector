========================================================================
VERITAS AI - JUPYTER TRAINING NOTEBOOKS & PRESENTATION DECK
========================================================================

Contents:
- Training Files/:
    * Train-COVID.ipynb: Jupyter notebook training the COVID NLP pipeline
    * Train-Taliban.ipynb: Jupyter notebook training the Taliban NLP pipeline
- fakenews_presentation_dataset 2/:
    * index.html: Interactive Major Project presentation deck (viewable in any browser)
    * generate_pptx.py: Python script to automatically compile slides to PowerPoint (.pptx)
    * presentation_claims.csv & fact_check_test_dataset_9_claims.csv: Benchmark claims
    * presentation_evidence.jsonl: Multimodal evidence records
