========================================================================
VERITAS AI - SPACY COVID-19 NLP MODEL PACKAGE
========================================================================

Contents:
- model/: Pre-trained SpaCy pipeline for COVID-19 fake news classification
  (tokenizer, tagger, parser, ner, textcat, word vectors)

Loading in Python:
    import spacy
    nlp = spacy.load("model")
    doc = nlp("Vaccines alter human DNA")
    print(doc.cats)
