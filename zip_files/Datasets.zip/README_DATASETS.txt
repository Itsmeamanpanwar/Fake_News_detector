========================================================================
VERITAS AI - RESEARCH DATASETS & BENCHMARK REPORTS
========================================================================

Contents:
- Datasets/:
    * COVID Fake News Data.csv: Labeled COVID-19 misinformation & real news corpus
    * afpfake.csv: AFP Fact-Check verified Afghanistan/Taliban claims dataset
- Error Benchmark CSVs:
    * afghanistan_errors.csv & covid_errors.csv: Discrepancy analysis files
    * afghanistan_confidence_errors.csv & covid_confidence_errors.csv: High-confidence misclassifications
- Analysis Reports:
    * confidence_report.txt: Statistical breakdown of prediction margins and confidence distributions
    * explanation_report.txt: Model explainability and feature attribution summary
    * presentation_evidence.jsonl: Curated 22-claim fact-check ground truth evidence
