========================================================================
VERITAS AI - BACKEND CORE & FACT-CHECKING ENGINE MODULE
========================================================================

Contents:
- factcheck_engine/:
    * collectors/ (Crossref, OpenAlex, Wikipedia live academic evidence collectors)
    * services/ (FactChecker, SemanticRetrieval, NLI entailment/contradiction inference, EvidenceStore)
    * data/ (Curated processed fact-checking evidence corpus)
- streamlit_factcheck.py: Full-stack Veritas AI Fact-Checking application
- app_sklearn.py: Fast ML prediction web app
- modelfinal.py: Core SpaCy NLP prediction pipeline
- Diagnostics & Analysis Suite:
    * train_models.py, analyze_errors.py, confidence_analysis.py, explain_prediction.py,
      dataset_quality.py, diagnose_model.py, duplicate_report.py, inspect_data.py
- Deployment manifests: requirements.txt, Procfile, setup.sh, runtime.txt

Installation & Execution:
1. Install Python dependencies:
   $ pip install -r requirements.txt
2. Launch Veritas AI Fact Checking Engine:
   $ streamlit run streamlit_factcheck.py
3. Or launch the Sklearn Classifier Web App:
   $ streamlit run app_sklearn.py
