========================================================================
VERITAS AI - LIGHTWEIGHT SKLEARN MACHINE LEARNING MODELS
========================================================================

These pre-trained models provide fast inference with minimal memory footprint (~2 MB zipped),
ideal for quick cloud deployment without loading heavy deep learning models.

Contents:
- models_sklearn/ & models_sklearn_v2/:
    * covid_model.joblib: TF-IDF + Classifier trained on COVID-19 dataset
    * afghanistan_model.joblib: TF-IDF + Classifier trained on Afghanistan dataset

Usage in Python:
    import joblib
    model = joblib.load('models_sklearn_v2/covid_model.joblib')
    prediction = model.predict(["Vaccines cause magnetic fields"])
